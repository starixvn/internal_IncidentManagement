require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

module RedmineMyPageQueries
end

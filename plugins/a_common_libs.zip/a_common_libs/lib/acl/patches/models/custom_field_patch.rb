module Acl::Patches::Models
  module CustomFieldPatch
    def self.included(base)
      base.class_eval do
        safe_attributes 'acl_trim_multiple', if: Proc.new { User.current.admin? }
      end
    end
  end
end
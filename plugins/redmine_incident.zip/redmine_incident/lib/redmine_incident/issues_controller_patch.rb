require_dependency 'application_controller'
require_dependency 'issues_controller'
require_dependency '../lib/redmine/pagination'

module IssuesControllerPatch
  def self.included(base)
    include Redmine::Pagination  
    
    base.class_eval do
      
      def index
        retrieve_query

    if @query.valid?
      respond_to do |format|
        format.html {
          @issue_count = @query.issue_count
          @issue_pages = Paginator.new @issue_count, per_page_option, params['page']
          @issues = @query.issues(:offset => @issue_pages.offset, :limit => @issue_pages.per_page)
          render :layout => !request.xhr?
        }
        format.api  {
          @offset, @limit = api_offset_and_limit
          @query.column_names = %w(author)
          @issue_count = @query.issue_count
          @issues = @query.issues(:offset => @offset, :limit => @limit)
          Issue.load_visible_relations(@issues) if include_in_api_response?('relations')
        }
        format.atom {
          @issues = @query.issues(:limit => Setting.feeds_limit.to_i)
          render_feed(@issues, :title => "#{@project || Setting.app_title}: #{l(:label_issue_plural)}")
        }
        format.csv  {
          @issues = @query.issues(:limit => Setting.issues_export_limit.to_i)
          send_data(query_to_csv(@issues, @query, params[:csv]), :type => 'text/csv; header=present', :filename => 'issues.csv')
        }
        format.pdf  {
          @issues = @query.issues(:limit => Setting.issues_export_limit.to_i)
          send_file_headers! :type => 'application/pdf', :filename => 'issues.pdf'
        }
      end
    else
      respond_to do |format|
        format.html { render :layout => !request.xhr? }
        format.any(:atom, :csv, :pdf) { head 422 }
        format.api { render_validation_errors(@query) }
      end
    end
  rescue ActiveRecord::RecordNotFound
    render_404
        end

    end
  end
end

IssuesController.send(:include, IssuesControllerPatch)